<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit();
}

// DB connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "b";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Handle post creation
    if (isset($_POST['create_post'])) {
        $title = $_POST['title'];
        $content = $_POST['content'];
        $status = $_POST['status'];

        $image = '';
        if (!empty($_FILES['image']['name'])) {
            $targetDir = "uploads/";
            $image = time() . "_" . basename($_FILES["image"]["name"]);
            $targetFile = $targetDir . $image;
            move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile);
        }

        $stmt = $conn->prepare("INSERT INTO posts (title, content, image, status) VALUES (?, ?, ?, ?)");
        $stmt->execute([$title, $content, $image, $status]);
    }

    // Fetch all posts
    $posts = $conn->query("SELECT * FROM posts ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("DB Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Posts</title>
    <style>
        body { font-family: Arial; background: #f4f4f4; margin: 0; padding: 20px; }
        h1 { color: #333; }
        .form-box, .table-box {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        input, textarea, select {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            margin-bottom: 15px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        input[type="submit"] {
            background-color: #28a745;
            color: white;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #218838;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 10px;
            border-bottom: 1px solid #ccc;
        }

        th {
            background-color: #007BFF;
            color: white;
        }

        .action a {
            margin-right: 10px;
            color: #007BFF;
            text-decoration: none;
        }

        .action a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<h1>Manage Posts</h1>

<div class="form-box">
    <h2>Create New Post</h2>
    <form method="POST" enctype="multipart/form-data">
        <label>Title</label>
        <input type="text" name="title" required>

        <label>Content</label>
        <textarea name="content" rows="5" required></textarea>

        <label>Image</label>
        <input type="file" name="image">

        <label>Status</label>
        <select name="status">
            <option value="published">Published</option>
            <option value="unpublished">Unpublished</option>
        </select>

        <input type="submit" name="create_post" value="Create Post">
    </form>
</div>

<div class="table-box">
    <h2>All Posts</h2>
    <table>
        <thead>
            <tr>
                <th>Title</th>
                <th>Status</th>
                <th>Image</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($posts as $post): ?>
                <tr>
                    <td><?php echo htmlspecialchars($post['title']); ?></td>
                    <td><?php echo htmlspecialchars($post['status']); ?></td>
                    <td>
                        <?php if ($post['image']): ?>
                            <img src="uploads/<?php echo $post['image']; ?>" width="50">
                        <?php else: ?>
                            No image
                        <?php endif; ?>
                    </td>
                    <td class="action">
                        <a href="edit_post.php?id=<?php echo $post['id']; ?>">Edit</a>
                        <a href="delete_post.php?id=<?php echo $post['id']; ?>" onclick="return confirm('Delete this post?')">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

</body>
</html>
