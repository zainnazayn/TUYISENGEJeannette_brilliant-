<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit();
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "b";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Get quick stats
    $userCount = $conn->query("SELECT COUNT(*) FROM users")->fetchColumn();
    $postCount = $conn->query("SELECT COUNT(*) FROM posts")->fetchColumn(); // Assume 'posts' table
} catch (PDOException $e) {
    die("DB Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <style>
        * { box-sizing: border-box; }
        body { font-family: Arial, sans-serif; margin: 0; background-color: #f9f9f9; }

        .sidebar {
            width: 250px;
            height: 100vh;
            background-color: #333;
            position: fixed;
            top: 0; left: 0;
            padding-top: 30px;
        }

        .sidebar a {
            display: block;
            color: white;
            padding: 15px 25px;
            text-decoration: none;
            transition: 0.3s;
        }

        .sidebar a:hover {
            background-color: #575757;
        }

        .main {
            margin-left: 250px;
            padding: 20px;
        }

        h1 {
            color: #333;
        }

        .stats {
            display: flex;
            gap: 20px;
            margin-bottom: 30px;
        }

        .card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            flex: 1;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .card h2 {
            margin: 0;
            font-size: 22px;
            color: #007BFF;
        }

        .card p {
            font-size: 16px;
        }

        .content-section {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .logout-btn {
            background-color: #e74c3c;
            color: white;
            padding: 10px 20px;
            border: none;
            margin-top: 20px;
            cursor: pointer;
            border-radius: 5px;
        }

        .logout-btn:hover {
            background-color: #c0392b;
        }
    </style>
</head>
<body>

<div class="sidebar">
    <a href="admin_dashboard.php">Dashboard Home</a>
    <a href="manage_posts.php">Manage Posts</a>
    <a href="manage_pages.php">Manage Pages</a>
    <a href="file_uploads.php">File Uploads</a>
    <a href="logout.php">Logout</a>
</div>

<div class="main">
    <h1>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h1>

    <div class="stats">
        <div class="card">
            <h2><?php echo $userCount; ?></h2>
            <p>Total Users</p>
        </div>
        <div class="card">
            <h2><?php echo $postCount; ?></h2>
            <p>Total Posts</p>
        </div>
        <div class="card">
            <h2>Recent</h2>
            <p>Activity Placeholder</p>
        </div>
    </div>

    <div class="content-section">
        <h2>Quick Links</h2>
        <ul>
            <li><a href="manage_posts.php">Create or Edit Posts</a></li>
            <li><a href="manage_pages.php">Edit Pages (e.g., About Us)</a></li>
            <li><a href="file_uploads.php">Upload Documents/Images</a></li>
        </ul>
    </div>
</div>

</body>
</html>
