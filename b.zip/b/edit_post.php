<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "b";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Get post by ID
    if (!isset($_GET['id'])) {
        die("No post ID provided.");
    }

    $id = $_GET['id'];
    $stmt = $conn->prepare("SELECT * FROM posts WHERE id = ?");
    $stmt->execute([$id]);
    $post = $stmt->fetch();

    if (!$post) {
        die("Post not found.");
    }

    // Handle form submission
    if (isset($_POST['update_post'])) {
        $title = $_POST['title'];
        $content = $_POST['content'];
        $status = $_POST['status'];

        $image = $post['image']; // Keep existing image unless replaced
        if (!empty($_FILES['image']['name'])) {
            $targetDir = "uploads/";
            $image = time() . "_" . basename($_FILES["image"]["name"]);
            $targetFile = $targetDir . $image;
            move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile);
        }

        $stmt = $conn->prepare("UPDATE posts SET title = ?, content = ?, image = ?, status = ? WHERE id = ?");
        $stmt->execute([$title, $content, $image, $status, $id]);

        header("Location: manage_posts.php?updated=1");
        exit();
    }

} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Post</title>
    <style>
        body { font-family: Arial; background: #f4f4f4; padding: 20px; }
        .container {
            width: 600px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 0 10px #ccc;
        }
        h2 { text-align: center; }
        label { display: block; margin-top: 10px; }
        input[type="text"], textarea, select {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        input[type="file"] {
            margin-top: 5px;
        }
        input[type="submit"] {
            margin-top: 15px;
            background: #007BFF;
            color: white;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background: #0056b3;
        }
        .back-link {
            margin-top: 20px;
            text-align: center;
        }
        .back-link a {
            color: #007BFF;
            text-decoration: none;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Edit Post</h2>
    <form method="POST" enctype="multipart/form-data">
        <label>Title</label>
        <input type="text" name="title" value="<?php echo htmlspecialchars($post['title']); ?>" required>

        <label>Content</label>
        <textarea name="content" rows="6" required><?php echo htmlspecialchars($post['content']); ?></textarea>

        <label>Current Image:</label>
        <?php if ($post['image']): ?>
            <img src="uploads/<?php echo $post['image']; ?>" width="100"><br>
        <?php else: ?>
            No image uploaded.<br>
        <?php endif; ?>

        <label>Change Image</label>
        <input type="file" name="image">

        <label>Status</label>
        <select name="status">
            <option value="published" <?php if ($post['status'] == 'published') echo 'selected'; ?>>Published</option>
            <option value="unpublished" <?php if ($post['status'] == 'unpublished') echo 'selected'; ?>>Unpublished</option>
        </select>

        <input type="submit" name="update_post" value="Update Post">
    </form>

    <div class="back-link">
        <a href="manage_posts.php">← Back to Manage Posts</a>
    </div>
</div>

</body>
</html>
