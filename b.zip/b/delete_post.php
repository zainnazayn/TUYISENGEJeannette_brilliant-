<?php
session_start();

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "b";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if (!isset($_GET['id'])) {
        die("No post ID specified.");
    }

    $postId = $_GET['id'];

    // Get the image filename before deletion
    $stmt = $conn->prepare("SELECT image FROM posts WHERE id = ?");
    $stmt->execute([$postId]);
    $post = $stmt->fetch();

    if (!$post) {
        die("Post not found.");
    }

    // Delete the image file if it exists
    if (!empty($post['image']) && file_exists("uploads/" . $post['image'])) {
        unlink("uploads/" . $post['image']);
    }

    // Delete the post
    $stmt = $conn->prepare("DELETE FROM posts WHERE id = ?");
    $stmt->execute([$postId]);

    header("Location: manage_posts.php?deleted=1");
    exit();

} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>
