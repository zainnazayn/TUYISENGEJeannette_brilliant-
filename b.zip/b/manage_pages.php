<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit();
}

$servername = "localhost";
$db_username = "root";
$db_password = "";
$dbname = "b";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $db_username, $db_password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Update page content
    if (isset($_POST['update_page'])) {
        $id = $_POST['id'];
        $title = $_POST['title'];
        $content = $_POST['content'];

        $stmt = $conn->prepare("UPDATE pages SET title = ?, content = ? WHERE id = ?");
        $stmt->execute([$title, $content, $id]);

        $success = "Page updated successfully.";
    }

    // Fetch all pages
    $stmt = $conn->query("SELECT * FROM pages");
    $pages = $stmt->fetchAll();

} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Pages</title>
    <style>
        body { font-family: Arial; background: #f4f4f4; padding: 20px; }
        .container { max-width: 900px; margin: auto; background: white; padding: 25px; border-radius: 10px; box-shadow: 0 0 10px #ccc; }
        h2 { text-align: center; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 10px; border: 1px solid #ddd; text-align: left; }
        textarea, input[type="text"] {
            width: 100%; padding: 8px; margin-top: 5px; border: 1px solid #ccc; border-radius: 5px;
        }
        input[type="submit"] {
            background: #28a745; color: white; border: none; padding: 8px 15px; cursor: pointer; margin-top: 10px;
        }
        input[type="submit"]:hover {
            background: #218838;
        }
        .success { color: green; margin-top: 10px; text-align: center; }
    </style>
</head>
<body>
<div class="container">
    <h2>Manage Pages</h2>

    <?php if (isset($success)) echo "<p class='success'>$success</p>"; ?>

    <?php foreach ($pages as $page): ?>
        <form method="POST" action="">
            <input type="hidden" name="id" value="<?php echo $page['id']; ?>">
            <label>Page Title:</label>
            <input type="text" name="title" value="<?php echo htmlspecialchars($page['title']); ?>" required>

            <label>Content:</label>
            <textarea name="content" rows="6" required><?php echo htmlspecialchars($page['content']); ?></textarea>

            <input type="submit" name="update_page" value="Update Page">
        </form>
        <hr>
    <?php endforeach; ?>
</div>
</body>
</html>
