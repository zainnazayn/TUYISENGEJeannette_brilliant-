<?php
session_start();

$servername = "localhost";
$db_username = "root";
$db_password = "";
$dbname = "b";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $db_username, $db_password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if (isset($_POST['login'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];

        $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            if ($user['role'] === 'admin') {
                $_SESSION['admin_logged_in'] = true;
                $_SESSION['username'] = $user['username'];

                header("Location: admin_dashboard.php");
                exit();
            } else {
                $error = "Access denied. Not an admin.";
            }
        } else {
            $error = "Invalid username or password.";
        }
    }
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Login</title>
    <style>
        body { font-family: Arial; background: #f2f2f2; padding: 50px; }
        .box { width: 400px; margin: auto; background: white; padding: 25px; border-radius: 10px; box-shadow: 0 0 10px #ccc; }
        h2 { text-align: center; }
        input[type="text"], input[type="password"], input[type="submit"] {
            width: 100%; padding: 10px; margin-top: 10px; border-radius: 5px; border: 1px solid #ccc;
        }
        input[type="submit"] {
            background: #007BFF; color: white; border: none;
        }
        .error { color: red; text-align: center; }
        .link { text-align: center; margin-top: 10px; }
    </style>
</head>
<body>
<div class="box">
    <h2>Admin Login</h2>
    <?php if (!empty($error)) echo "<p class='error'>$error</p>"; ?>
    <form method="POST">
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <input type="submit" name="login" value="Login">
    </form>
    <div class="link">
        <p>Not registered yet? <a href="admin_registration.php">Register</a></p>
    </div>
</div>
</body>
</html>
