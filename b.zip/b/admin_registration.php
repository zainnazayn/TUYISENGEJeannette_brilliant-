<?php
session_start();

$servername = "localhost";
$db_username = "root";
$db_password = "";
$dbname = "b";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $db_username, $db_password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if (isset($_POST['register'])) {
        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $role = 'admin';

        $sql = "INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);

        if ($stmt->execute([$username, $email, $password, $role])) {
            echo "<p style='color:green;text-align:center;'>Admin registered successfully.</p>";
        } else {
            echo "<p style='color:red;text-align:center;'>Error: " . $stmt->errorInfo()[2] . "</p>";
        }
    }
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Registration</title>
    <style>
        body { font-family: Arial; background: #f4f4f4; padding: 50px; }
        .container { width: 400px; margin: auto; background: #fff; padding: 20px; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.2); }
        h2 { text-align: center; color: #333; }
        input[type="text"], input[type="email"], input[type="password"], input[type="submit"] {
            width: 100%; padding: 10px; margin-top: 10px; border-radius: 5px; border: 1px solid #ccc;
        }
        input[type="submit"] {
            background: #28a745; color: white; border: none;
        }
        .link { text-align: center; margin-top: 15px; }
    </style>
</head>
<body>
<div class="container">
    <h2>Admin Registration</h2>
    <form method="POST">
        <input type="text" name="username" placeholder="Username" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <input type="submit" name="register" value="Register">
    </form>
    <div class="link">
        <p>Already registered? <a href="login.php">Login here</a></p>
    </div>
</div>
</body>
</html>
