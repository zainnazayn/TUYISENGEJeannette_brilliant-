<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "b";
$upload_dir = "uploads/";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $message = "";

    if (isset($_POST['upload'])) {
        if (!empty($_FILES['file']['name'])) {
            $original_name = basename($_FILES["file"]["name"]);
            $target_file = $upload_dir . time() . "_" . $original_name;

            $allowed_types = ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'docx', 'doc'];
            $file_ext = strtolower(pathinfo($original_name, PATHINFO_EXTENSION));

            if (in_array($file_ext, $allowed_types)) {
                if (!file_exists($upload_dir)) {
                    mkdir($upload_dir, 0755, true); // Create uploads folder if not exists
                }

                if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
                    $stmt = $conn->prepare("INSERT INTO uploaded_files (filename, filepath) VALUES (?, ?)");
                    $stmt->execute([$original_name, $target_file]);
                    $message = "File uploaded successfully.";
                } else {
                    $message = "Failed to upload file.";
                }
            } else {
                $message = "Invalid file type. Only images, PDF, and Word docs are allowed.";
            }
        } else {
            $message = "Please choose a file.";
        }
    }

    // Fetch uploaded files
    $stmt = $conn->query("SELECT * FROM uploaded_files ORDER BY uploaded_at DESC");
    $files = $stmt->fetchAll();

} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>File Uploads</title>
    <style>
        body { font-family: Arial; background: #f8f8f8; padding: 20px; }
        .container { max-width: 800px; margin: auto; background: white; padding: 25px; border-radius: 8px; box-shadow: 0 0 10px #ccc; }
        h2 { text-align: center; }
        input[type="file"], input[type="submit"] {
            margin-top: 15px;
            display: block;
            width: 100%;
            padding: 10px;
        }
        table { width: 100%; margin-top: 25px; border-collapse: collapse; }
        th, td { padding: 10px; border: 1px solid #ddd; }
        .msg { text-align: center; color: green; font-weight: bold; }
    </style>
</head>
<body>
<div class="container">
    <h2>Upload a File</h2>
    <?php if (!empty($message)) echo "<p class='msg'>$message</p>"; ?>
    <form method="POST" enctype="multipart/form-data">
        <input type="file" name="file" required>
        <input type="submit" name="upload" value="Upload File">
    </form>

    <h3>Uploaded Files</h3>
    <?php if (count($files) > 0): ?>
        <table>
            <tr>
                <th>File Name</th>
                <th>Uploaded At</th>
                <th>Action</th>
            </tr>
            <?php foreach ($files as $file): ?>
                <tr>
                    <td><?php echo htmlspecialchars($file['filename']); ?></td>
                    <td><?php echo $file['uploaded_at']; ?></td>
                    <td><a href="<?php echo $file['filepath']; ?>" target="_blank">View</a></td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php else: ?>
        <p>No files uploaded yet.</p>
    <?php endif; ?>
</div>
</body>
</html>
